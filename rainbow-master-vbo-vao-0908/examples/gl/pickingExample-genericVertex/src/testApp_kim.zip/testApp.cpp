#include "testApp.h"
#include "ofAppGLFWWindow.h"


//#include "ofConstants.h"
//#include "ofGLUtils.h"

//#include "pickerwindow.h" 

//#define USE_PROGRAMMABLE_GL

// from PickingMat

#include "shadergeometry.h" // includes Object class

#include "shadermaterial.h"
#include "glsupport.h"
#include "Wm5DistPoint3Triangle3.h"
#include "Wm5DistPoint3Box3.h"

#include "picker_0.h"


#include "ppm.h"
#include <stdio.h>


#include "stdafx.h"
#include "api.h"
#include "probes.h"
#include "parser.h"
#include "parallel.h"

bool ParseFile(const string &filename);
extern int g_argc;
extern char **g_argv;
extern int render_flag;
// extern GLFWwindow* ofAppGLFWWindow::windowP; => glfwSawpBuffers(windowP)
// static ofPtr<ofAppBaseWindow> 		window; => window.display()


// --------- Materials
ShaderMaterial *g_diffuseWithTexture;
ShaderMaterial *g_diffuseWithoutTexture;


shared_ptr<ShaderMaterial> g_redDiffuseMat,
                            g_blueDiffuseMat,
							g_greenDiffuseMat,
                            g_bumpFloorMat,
                            g_arcballMat,
                            g_pickingMat,
                            g_lightMat;

shared_ptr<ShaderMaterial> g_overridingMaterial;

// PickingMat

using namespace std;      // for string, vector, iostream, shared_ptr and other standard C++ stuff

/////////////////////
VertexPNTBX  *g_vertexOfMesh[1500];
unsigned short *g_indexOfMesh[1500];
int g_distance_index=0;
int g_distance_vindex[150];
int g_distance_iindex[150];

typedef struct voxelization{
	Point *p;
	float distances;
}voxel_;

typedef struct mortoncode{
	Wm5::Triangle3f triangle;
	Wm5::Vector3f center;
	char m[31];
	int m_int;
}morton;
struct morton_tree;
typedef struct morton_tree{
	int tri_num;
	int code;
	int is_leaf;
	char code_[31];
	float shortest_distance;
	float max_x;
	float min_x;
	float max_y;
	float min_y;
	float min_z;
	float max_z;
	morton **t;
	struct morton_tree *child[8];
}mortonTree;
typedef struct bvh_tree;
typedef struct bvh_tree{
	float max_x;
	float min_x;
	float max_y;
	float min_y;
	float min_z;
	float max_z;

	float bvh_max_x;
	float bvh_min_x;
	float bvh_max_y;
	float bvh_min_y;
	float bvh_min_z;
	float bvh_max_z;
	int number;
	struct bvh_tree *child[2];
	morton **t;
}bvhTree;

struct distance_file{
	
	float distances[8];
	

};
morton Morton[99999];
struct distance_file shortestDistance[35000];
int *g_search;
void make_bvh(bvhTree *p,int level,int cur_level,char *parent,float x_min,float x_max,float y_min,float y_max,float z_min,float z_max);
void make_mt_tree(mortonTree *p,int level,int cur_level,char *parent,float x_min,float x_max,float y_min,float y_max,float z_min,float z_max);
void get_distance_bvh(mortonTree *p,bvhTree *q,int cur_level,int level);
int distanceToFile(mortonTree *cur,int cur_level,int level,int index);
void get_distance_field_morton(int level,int cur_level,int pre_morton);
int triangle_in_morton[1500];
voxel_ morton_distance[1500];
//voxel_ Voxel[256][256][256];

mortonTree *g_DistanceTree_root;
bvhTree *g_BvhTree_root;

float g_x_max=-99999;
float g_y_max=-99999;
float g_z_max=-99999;
float g_x_min=99999;
float g_y_min=99999;
float g_z_min=99999;
		/////////////////////
bool g_Gl2Compatible = false;

// set the parameters for the camera, which define the internal working of the camera.
double  g_frustMinFov = 60.0;  // A minimal of 60 degree field of view
double  g_frustFovY = g_frustMinFov; // FOV in y direction (updated by updateFrustFovY)

double  g_frustNear = 0.1;    // near plane
double  g_frustFar = 50.0;    // far plane


int g_windowWidth; 
int g_windowHeight; 


bool g_mouseClickDown = false;    // is the mouse button pressed
bool g_mouseLClickButton, g_mouseRClickButton, g_mouseMClickButton;

int g_prev_mouseClickX, g_prev_mouseClickY; // coordinates for mouse click event

int  g_pressed_button;

int g_activeShader = 0;

bool g_camera_mode = false;
bool g_backgroundBackedUp = false;

bool g_picking_mode = false; // mode during the process of picking
bool g_picked_mode = false;

bool g_rotation_mode  = false;

GLdouble g_clearColor[4];


// --------- Scene
// --------- Scene

Cvec4 g_light1Pos(2.0, 3.0, 14.0, 1.0), g_light2Pos(-2, -3.0, -5.0, 1.0);  // define two lights positions in world space

Cvec4 g_light1Color(1.0, 1.0, 1.0, 1.0);
Cvec4 g_light2Color(1.0, 1.0, 1.0, 1.0);

Matrix4 g_eyeRbt = Matrix4::makeTranslation( Cvec3(0.0, 0.25, 10.0) ); // ClASS METHOD CALL => AN INSTANCE OF MATRIX4


//  void makeTranslationMatrix( const ofVec3f& );
//	void makeTranslationMatrix( float, float, float );
// shared_ptr< Picker > g_picker_ptr;
// g_picker_ptr.reset( new Picker() );

Picker g_picker; // default constructor

shared_ptr< Object>  g_currentPickedObject;

// references are not objects, i.e. types regions of storage; so they are not actually "variables";
// you cannot point to references; so there are no references of references, array of references, pointers to
// references. They are just aliases of other variables. So, you cannot use vector < Object & > objectList

vector < shared_ptr<Object> >  g_objectList;


//--------------------------------------------------------------
testApp:: testApp() 

{
}

void testApp::setup(){
	
    //ofSetBackgroundAuto( false); // It will make a single buffering by drawing to the front buffer
	ofSetBackgroundAuto( true);


	g_windowWidth = ofGetWidth(); 
	g_windowHeight = ofGetHeight(); 

	initGLState();
    initMaterials();
    initObjects();

	//voxel();
}

void testApp::exit() {


}


Matrix4 testApp::makeProjectionMatrix() {

	return Matrix4::makeProjection(
		g_frustFovY, g_windowWidth / static_cast <double> (g_windowHeight),
		-g_frustNear, -g_frustFar);
}


// update g_frustFovY from g_frustMinFov, g_windowWidth, and g_windowHeight
void testApp::updateFrustFovY() {

  if (g_windowWidth >= g_windowHeight)
    g_frustFovY = g_frustMinFov;

  else {
    const double RAD_PER_DEG = 0.5 * 3.14159 /180;
    g_frustFovY = atan2(sin(g_frustMinFov * RAD_PER_DEG) * g_windowHeight / g_windowWidth, cos(g_frustMinFov * RAD_PER_DEG)) / RAD_PER_DEG;
  }
}

//--------------------------------------------------------------
void testApp::update(){

}

static bool backgroundBackedUp = false;


int triangle_index=0;

int position=0;
int distanceToFile(mortonTree *cur,int cur_level,int level,int index){

	mortonTree *temp;
	FILE *fp;
	static int max_index=-1;
	int cur_index=index;
	for(int i=0;i<8;i++){
		if(index>max_index)
			max_index=index;
		temp=cur->child[i];
		if(temp->shortest_distance>0){
			shortestDistance[cur_index].distances[i]=temp->shortest_distance;
		}
		else if(temp->shortest_distance<0){
			position++;
			shortestDistance[cur_index].distances[i]=-(position);
			distanceToFile(temp,cur_level+1,level,position);	
		}
	}
	return max_index;
}
void testApp::voxel(){
	int i,j,l,m=0;
	
	int level=0;
	int k=6;
	float x0,x1,x2;
	float y0,y1,y2;
	float z0,z1,z2;
	int flag1=0,flag2=0,flag3=0;
	g_search=new int[k+1];
	for(int i=0;i<k+1;i++){
		g_search[i]=0;
	}
	int temp=0,temp2=0;

	for(int i=0;i<1500;i++){
		triangle_in_morton[i]=0;
	}
	
	for(int i=0;i<35000;i++){
		for(int j=0;j<8;j++){
			shortestDistance[i].distances[j]=0;
			}
	}

 	float x=0.0;
	float y=0.0;
	float z=1.0;
	FILE *fp;
	//fp=fopen("distancefield.txt","w");
	Wm5::Vector3<float> a(x,y,z);
	Wm5::Vector3<float> t1(1,0,0);
	Wm5::Vector3<float> t2(0,1,0);
	Wm5::Vector3<float> t3(-1,-1,0);
	Wm5::Triangle3f tri(t1,t2,t3);

	Wm5::DistPoint3Triangle3f dis(a,tri);
	float distance=dis.Get();
	/*
	float unit_length_x= (g_x_max-g_x_min)/256;
	float unit_length_y= (g_y_max-g_y_min)/256;
	float unit_length_z= (g_z_max-g_z_min)/256;
	for(i=0;i<256;i++){
		for(j=0;j<256;j++){
			for(k=0;k<256;k++){
				Voxel[i][j][k].p=new Point(g_x_min+(i+0.5)*unit_length_x,g_y_min+(j+0.5)*unit_length_y,g_z_min+(k+0.5)*unit_length_z);
				Voxel[i][j][k].distances=999999;
				Wm5::Vector3f points(g_x_min+(i+0.5)*unit_length_x,g_y_min+(j+0.5)*unit_length_y,g_z_min+(k+0.5)*unit_length_z);
					for (  l = 0; l<g_distance_index ; l++ ) {
						for(m=0;m<g_distance_vindex[l];m=m+3){				
							Cvec3f a=g_vertexOfMesh[l][g_indexOfMesh[l][m]].get();
							Cvec3f b=g_vertexOfMesh[l][g_indexOfMesh[l][m+1]].get();
							Cvec3f c=g_vertexOfMesh[l][g_indexOfMesh[l][m+2]].get();
							Wm5::Vector3<float> t1(a[0],a[1],a[2]);
							Wm5::Vector3<float> t2(b[0],b[1],b[2]);
							Wm5::Vector3<float> t3(c[0],c[1],c[2]);
							Wm5::Triangle3f tri(t1,t2,t3);
							Wm5::DistPoint3Triangle3f dis(points,tri);
							if(Voxel[i][j][k].distances>dis.Get())
								Voxel[i][j][k].distances=dis.Get();
						}
					}
				fprintf(fp,"%d %d %d  %f\n",i,j,k,Voxel[i][j][k].distances);
			}
		}
	}
	fclose(fp);
	*/
	for (  l = 0; l<g_distance_index ; l++ ) {
		for(m=0;m<g_distance_vindex[l];m=m+3){				
			Cvec3f a=g_vertexOfMesh[l][g_indexOfMesh[l][m]].get();
			Cvec3f b=g_vertexOfMesh[l][g_indexOfMesh[l][m+1]].get();
			Cvec3f c=g_vertexOfMesh[l][g_indexOfMesh[l][m+2]].get();
			Wm5::Vector3<float> t1(a[0],a[1],a[2]);
			Wm5::Vector3<float> t2(b[0],b[1],b[2]);
			Wm5::Vector3<float> t3(c[0],c[1],c[2]);
			Wm5::Vector3f t4( (a[0]+b[0]+c[0])/3,(a[1]+b[1]+c[1])/3,(a[2]+b[2]+c[2])/3); 
			Wm5::Triangle3f tri(t1,t2,t3);
			//Wm5::DistPoint3Triangle3f dis(points,tri);
			//if(Voxel[i][j][k].distances>dis.Get())
			//	Voxel[i][j][k].distances=dis.Get();
			Morton[triangle_index].triangle=tri;
			Morton[triangle_index].center=t4;
			x0=g_x_min; x2=g_x_max; y0=g_y_min; y2=g_y_max; z0=g_z_min; z2=g_z_max;
			temp=0;
	//		flag1=0;
	//		flag2=0;
	//		flag3=0;
			//////////////////////////////////morton code 
			for(level=0;level<k;level++){
				temp2=0;
				x1=(x0+x2)/2;
				y1=(y0+y2)/2;
				z1=(z0+z2)/2;
				temp=temp<<1;
				if(t4.X() >= x1){
					Morton[triangle_index].m[level*3]='1';
					
					temp+=1;
					temp2+=1;
					x0=x1;
				}
				else{
					Morton[triangle_index].m[level*3]='0';
					x2=x1;
				}
				temp=temp<<1;
				temp2=temp2<<1;
				if(t4.Y() >= y1){
					//temp=temp<<1;
					temp+=1;
					Morton[triangle_index].m[level*3+1]='1';
					y0=y1;
					temp2+=1;
				}
				else{
					Morton[triangle_index].m[level*3+1]='0';
					y2=y1;
				}
				temp=temp<<1;
				temp2=temp2<<1;
				if(t4.Z() >= z1){
					//temp=temp<<1;
					temp+=1;
					Morton[triangle_index].m[level*3+2]='1';
					z0=z1;
					temp2+=1;
				}
				else{
					Morton[triangle_index].m[level*3+2]='0';
					z2=z1;
				}
				/*
				if(temp2==0 && level==0){
					flag1=1;
				}
				if(flag1==1 && temp2==0 && level==1){
					flag2=1;
				}
				if( flag2==1 && temp2==0 &&level==2){
					flag3=1;
				}*/
//				triangle_in_morton[temp+1024*flag1+64*flag2+8*flag3]++;
				//flag3=0;
			}
			Morton[triangle_index].m_int=temp;
			/////////////////////////////////////////////////
			triangle_index++;
		}
	}

	//////////////////////////////////morton code sorting/////////
	for(i=0;i<triangle_index-1;i++){
		for(int j=0;j<triangle_index-i-1;j++){
			if( Morton[j].m_int > Morton[j+1].m_int){
					morton temp5;
					temp5.center=Morton[j].center;
					strcpy(temp5.m,Morton[j].m);
					temp5.m_int=Morton[j].m_int;
					temp5.triangle=Morton[j].triangle;

					Morton[j].center=Morton[j+1].center;
					strcpy(Morton[j].m,Morton[j+1].m);
					Morton[j].m_int=Morton[j+1].m_int;
					Morton[j].triangle=Morton[j+1].triangle;

					Morton[j+1].center=temp5.center;
					strcpy(Morton[j+1].m,temp5.m);
					Morton[j+1].m_int=temp5.m_int;
					Morton[j+1].triangle=temp5.triangle;
			}
		}
	}
	
	x0=g_x_min; x2=g_x_max; y0=g_y_min; y2=g_y_max; z0=g_z_min; z2=g_z_max;
	int level0_x;
	g_DistanceTree_root=new mortonTree;
	g_BvhTree_root=new bvhTree;

	make_mt_tree(g_DistanceTree_root,k,0,NULL,g_x_min,g_x_max,g_y_min,g_y_max,g_z_min, g_z_max);
//	get_distance_field_morton(k,0,0);
	make_bvh(g_BvhTree_root,k,0,NULL,g_x_min,g_x_max,g_y_min,g_y_max,g_z_min, g_z_max);
 	get_distance_bvh(g_DistanceTree_root,g_BvhTree_root,0,k);
	int max_index=distanceToFile(g_DistanceTree_root,0,k,0);
	fp=fopen("distancefield.txt","w");
	for(int i=0;i<max_index+1;i++){
			fprintf(fp,"%f %f %f %f %f %f %f %f \n",shortestDistance[i].distances[0],shortestDistance[i].distances[1],shortestDistance[i].distances[2],shortestDistance[i].distances[3],shortestDistance[i].distances[4],shortestDistance[i].distances[5],shortestDistance[i].distances[6],shortestDistance[i].distances[7]);
	}
	fclose(fp);



//	VertexPNTBX  *g_vertexOfMesh[150];
//  unsigned short *g_indexOfMesh[150];
	Wm5::Vector3f points( (g_DistanceTree_root->child[7]->child[2]->child[6]->max_x+g_DistanceTree_root->child[7]->child[2]->child[6]->min_x)/2, (g_DistanceTree_root->child[7]->child[2]->child[6]->max_y+g_DistanceTree_root->child[7]->child[2]->child[6]->min_y)/2,(g_DistanceTree_root->child[7]->child[2]->child[6]->max_z+g_DistanceTree_root->child[7]->child[2]->child[6]->min_z)/2);
	float distances=99999;
	for (int  l = 0; l<g_distance_index ; l++ ) {
						for(m=0;m<g_distance_vindex[l];m=m+3){				
							Cvec3f a=g_vertexOfMesh[l][g_indexOfMesh[l][m]].get();
							Cvec3f b=g_vertexOfMesh[l][g_indexOfMesh[l][m+1]].get();
							Cvec3f c=g_vertexOfMesh[l][g_indexOfMesh[l][m+2]].get();
							Wm5::Vector3<float> t1(a[0],a[1],a[2]);
							Wm5::Vector3<float> t2(b[0],b[1],b[2]);
							Wm5::Vector3<float> t3(c[0],c[1],c[2]);
							Wm5::Triangle3f tri(t1,t2,t3);
							Wm5::DistPoint3Triangle3f dis(points,tri);
							if(distances>dis.Get())
								distances=dis.Get();					
						}
					}
	//
	printf("asdf");
	return ;
}


float get_distance_bvh_2(Wm5::Vector3<float> a , bvhTree *p,float prev_distance,int cur_level,int level);
float get_distance_bvh_2(Wm5::Vector3<float> a , bvhTree *p,float prev_distance,int cur_level,int level){

	float cur_distance=0;
	static float initial_distance;
	if(cur_level==0){
		Wm5::DistPoint3Triangle3f dis(a,Morton[0].triangle);
		initial_distance = dis.Get();
	}
	/////////////////////////////////////////////////////////////////////////
	bvhTree *temp;
	for(int i=0;i<2;i++){
	temp= p->child[i];

	Wm5::Vector3f cen( (temp->bvh_max_x+temp->bvh_min_x)/2,(temp->bvh_max_y+temp->bvh_min_y)/2,(temp->bvh_max_z+temp->bvh_min_z)/2);
	Wm5::Vector3f ax0(1,0,0);
	Wm5::Vector3f ax1(0,1,0);
	Wm5::Vector3f ax2(0,0,1);

	Wm5::Box3<float> bounding_box(cen,ax0,ax1,ax2,(temp->bvh_max_x-temp->bvh_min_x)/2,(temp->bvh_max_y-temp->bvh_min_y)/2,(temp->bvh_max_z-temp->bvh_min_z)/2);
	Wm5::DistPoint3Box3<float> distance_box(a,bounding_box);
	cur_distance=distance_box.Get()+prev_distance;
	if(cur_distance < initial_distance){
		if(cur_level!=2 )
			get_distance_bvh_2(a,temp,cur_distance,cur_level+1,level);
		if(cur_level==2){
			for(int i=0;i<temp->number;i++){
				Wm5::DistPoint3Triangle3f dis_point_triangle(a,temp->t[i]->triangle);
				if( dis_point_triangle.Get() < initial_distance)
					initial_distance=dis_point_triangle.Get();
			}
		}
	}
	}

	/*
	temp= p->child[1];
	Wm5::Vector3f cen_( (temp->bvh_max_x+temp->bvh_min_x)/2,(temp->bvh_max_y+temp->bvh_min_y)/2,(temp->bvh_max_z+temp->bvh_min_z)/2);
	Wm5::Vector3f ax0_(1,0,0);
	Wm5::Vector3f ax1_(0,1,0);
	Wm5::Vector3f ax2_(0,0,1);
	Wm5::Box3<float> bounding_box_(cen_,ax0_,ax1_,ax2_,(temp->bvh_max_x-temp->bvh_min_x)/2,(temp->bvh_max_y-temp->bvh_min_y)/2,(temp->bvh_max_z-temp->bvh_min_z)/2);
	Wm5::DistPoint3Box3<float> distance_box_(a,bounding_box_);
	cur_distance=distance_box_.Get()+prev_distance;
	//if(cur_distance > initial_distance){
	//	return -100;
	//}
	if(cur_distance < initial_distance){
		if(cur_level!=2 )
			get_distance_bvh_2(a,temp,cur_distance,cur_level+1,level);
		if(cur_level==2){
			for(int i=0;i<temp->number;i++){
				Wm5::DistPoint3Triangle3f dis_point_triangle(a,temp->t[i]->triangle);
				if( dis_point_triangle.Get() < initial_distance)
					initial_distance=dis_point_triangle.Get();
			}
		}
	}
	*/
	//temp 
	return initial_distance;
}
void get_distance_bvh(mortonTree *p,bvhTree *q,int cur_level,int level){

	mortonTree *temp;
	for(int i=0;i<8;i++){
		temp=p->child[i];
		if(temp->tri_num > 3 && cur_level !=level-1){
			temp->shortest_distance=-1;
			get_distance_bvh(temp,q,cur_level+1,level);
		
		}
		else if( (temp->tri_num>=0 && temp->tri_num<=3) || level-1 ==cur_level ){
			Wm5::Vector3<float> a( (temp->max_x+temp->min_x)/2 , (temp->max_y+temp->min_y)/2, (temp->max_z+temp->min_z)/2);
			temp->shortest_distance=get_distance_bvh_2(a,q,0,0,level);
		}
	}
	/*
	temp=p->child[0];
	if(temp->tri_num > 3 && level !=2){
		temp->shortest_distance=-1;
		get_distance_bvh(temp,q,level+1);
	}
	else if(temp->tri_num<=3 || level ==2 ){
		Wm5::Vector3<float> a( (temp->max_x+temp->min_x)/2 , (temp->max_y+temp->min_y)/2, (temp->max_z+temp->min_z)/2);
		temp->shortest_distance=get_distance_bvh_2(a,q,0,0);
	}
	//Wm5::Vector3<float> a(x,y,z);
	//Wm5::Vector3<float> t1(1,0,0);
	//Wm5::Vector3<float> t2(0,1,0);
	///Wm5::Vector3<float> t3(-1,-1,0);
	//Wm5::Triangle3f tri(t1,t2,t3);
	//Wm5::DistPoint3Triangle3f dis(a,tri);
	temp=p->child[1];
	if(temp->tri_num > 3 && level !=2){
		temp->shortest_distance=-1;
		get_distance_bvh(temp,q,level+1);	
	}
	*/
}
void determine_bvh_coordinate(bvhTree temp,morton compare);
void determine_bvh_coordinate(float &temp_max_x,float &temp_min_x,float &temp_max_y,float &temp_min_y,float &temp_max_z,float &temp_min_z,morton compare){
	if(temp_max_x < compare.triangle.V[0].X())
					temp_max_x = compare.triangle.V[0].X();
				if(temp_max_x <compare.triangle.V[1].X())
					temp_max_x =compare.triangle.V[1].X();
				if(temp_max_x < compare.triangle.V[2].X())
					temp_max_x =compare.triangle.V[2].X();

				if(temp_max_y <compare.triangle.V[0].Y())
					temp_max_y = compare.triangle.V[0].Y();
				if(temp_max_y <compare.triangle.V[1].Y())
					temp_max_y = compare.triangle.V[1].Y();
				if(temp_max_y < compare.triangle.V[2].Y())
					temp_max_y = compare.triangle.V[2].Y();

				if(temp_max_z < compare.triangle.V[0].Z())
					temp_max_z = compare.triangle.V[0].Z();
				if(temp_max_z< compare.triangle.V[1].Z())
					temp_max_z =compare.triangle.V[1].Z();
				if(temp_max_z <compare.triangle.V[2].Z())
					temp_max_z = compare.triangle.V[2].Z();
				//////////////////////////////////////////////////////////////////
				if(temp_min_x >compare.triangle.V[0].X())
					temp_min_x = compare.triangle.V[0].X();
				if(temp_min_x > compare.triangle.V[1].X())
					temp_min_x = compare.triangle.V[1].X();
				if(temp_min_x > compare.triangle.V[2].X())
					temp_min_x = compare.triangle.V[2].X();

				if(temp_min_y >compare.triangle.V[0].Y())
					temp_min_y = compare.triangle.V[0].Y();
				if(temp_min_y >compare.triangle.V[1].Y())
					temp_min_y = compare.triangle.V[1].Y();
				if(temp_min_y >compare.triangle.V[2].Y())
					temp_min_y =compare.triangle.V[2].Y();

				if(temp_min_z > compare.triangle.V[0].Z())
					temp_min_z =compare.triangle.V[0].Z();
				if(temp_min_z>compare.triangle.V[1].Z())
					temp_min_z = compare.triangle.V[1].Z();
				if(temp_min_z >compare.triangle.V[2].Z())
					temp_min_z = compare.triangle.V[2].Z();

				

}
void make_bvh(bvhTree *p,int level,int cur_level,char *parent,float x_min2,float x_max2,float y_min2,float y_max2,float z_min2,float z_max2){

	bvhTree *temp;
	float  temp_max_x=-9999999,temp_min_x=9999999;
	float temp_max_y=-9999999,temp_min_y=9999999;
	float temp_max_z=-9999999,temp_min_z=9999999;
	p->child[0]=new bvhTree;
	temp = p->child[0];
	if(cur_level==0){
		temp->max_x=(x_min2+x_max2)/2;
		temp->min_x=x_min2;
		temp->max_y=y_max2;
		temp->min_y=y_min2;
		temp->max_z=z_max2;
		temp->min_z=z_min2;
		temp_max_x=-9999999,temp_min_x=9999999;temp_max_y=-9999999,temp_min_y=9999999;temp_max_z=-9999999,temp_min_z=9999999;
		for(int i=0;i<triangle_index;i++){
			 
			if( Morton[i].center.X() <= temp->max_x &&  Morton[i].center.X() >= temp->min_x){
				determine_bvh_coordinate(temp_max_x,temp_min_x,temp_max_y,temp_min_y,temp_max_z,temp_min_z,Morton[i]);
			}
		}
		temp->bvh_max_x=temp_max_x;temp->bvh_max_y=temp_max_y;temp->bvh_max_z=temp_max_z;
		temp->bvh_min_x=temp_min_x;temp->bvh_min_y=temp_min_y;temp->bvh_min_z=temp_min_z;
		make_bvh(temp,level,cur_level+1,NULL,temp->min_x,temp->max_x,temp->min_y,temp->max_y,temp->min_z,temp->max_z);
	}

	if(cur_level==1){
		temp->max_x=x_max2;
		temp->min_x=x_min2;
		temp->max_y=(y_max2+y_min2)/2;
		temp->min_y=y_min2;
		temp->max_z=z_max2;
		temp->min_z=z_min2;
		 temp_max_x=-9999999,temp_min_x=9999999;temp_max_y=-9999999,temp_min_y=9999999;temp_max_z=-9999999,temp_min_z=9999999;
		for(int i=0;i<triangle_index;i++){
			if( Morton[i].center.X() <= temp->max_x &&  Morton[i].center.X() >= temp->min_x&& Morton[i].center.Y() <= temp->max_y &&  Morton[i].center.Y() >= temp->min_y){
				determine_bvh_coordinate(temp_max_x,temp_min_x,temp_max_y,temp_min_y,temp_max_z,temp_min_z,Morton[i]);	
			}
		}
		temp->bvh_max_x=temp_max_x;temp->bvh_max_y=temp_max_y;temp->bvh_max_z=temp_max_z;
		temp->bvh_min_x=temp_min_x;temp->bvh_min_y=temp_min_y;temp->bvh_min_z=temp_min_z;
		make_bvh(temp,level,cur_level+1,NULL,temp->min_x,temp->max_x,temp->min_y,temp->max_y,temp->min_z,temp->max_z);
	}

	if(cur_level==2){
		int num=0;
		temp->max_x=x_max2;
		temp->min_x=x_min2;
		temp->max_y=y_max2;
		temp->min_y=y_min2;
		temp->max_z=(z_max2+x_min2)/2;
		temp->min_z=z_min2;
		temp_max_x=-9999999,temp_min_x=9999999;temp_max_y=-9999999,temp_min_y=9999999;temp_max_z=-9999999,temp_min_z=9999999;
		for(int i=0;i<triangle_index;i++){
			if(  Morton[i].center.X() <= temp->max_x &&  Morton[i].center.X() >= temp->min_x&& Morton[i].center.Y() <= temp->max_y &&  Morton[i].center.Y() >= temp->min_y&&Morton[i].center.Z() <= temp->max_z &&  Morton[i].center.Z() >= temp->min_z){
				determine_bvh_coordinate(temp_max_x,temp_min_x,temp_max_y,temp_min_y,temp_max_z,temp_min_z,Morton[i]);
			}
		}
		temp->bvh_max_x=temp_max_x;temp->bvh_max_y=temp_max_y;temp->bvh_max_z=temp_max_z;
		temp->bvh_min_x=temp_min_x;temp->bvh_min_y=temp_min_y;temp->bvh_min_z=temp_min_z;
		for(int i=0;i<triangle_index;i++){
			if( Morton[i].center.X() <= temp->max_x &&  Morton[i].center.X() >= temp->min_x){
				if( Morton[i].center.Y() <= temp->max_y &&  Morton[i].center.Y() >= temp->min_y){
					if( Morton[i].center.Z() <= temp->max_z &&  Morton[i].center.Z() >= temp->min_z){
						num++;
					}
				}
			}
		}
		temp->number=num;
		temp->t= new morton*[num];
		int temp_index=0;
		for(int i=0;i<triangle_index;i++){
			if( Morton[i].center.X() <= temp->max_x &&  Morton[i].center.X() >= temp->min_x){
				if( Morton[i].center.Y() <= temp->max_y &&  Morton[i].center.Y() >= temp->min_y){
					if( Morton[i].center.Z() <= temp->max_z &&  Morton[i].center.Z() >= temp->min_z){
						temp->t[temp_index]=&Morton[i];
						temp_index++;
					}
				}
			}
		}
	}
	p->child[1]=new bvhTree;
	temp=p->child[1];
	if(cur_level==0){
		temp->max_x=x_max2;
		temp->min_x=(x_min2+x_max2)/2;;
		temp->max_y=y_max2;
		temp->min_y=y_min2;
		temp->max_z=z_max2;
		temp->min_z=z_min2;
		temp_max_x=-9999999,temp_min_x=9999999;temp_max_y=-9999999,temp_min_y=9999999;temp_max_z=-9999999,temp_min_z=9999999;
		for(int i=0;i<triangle_index;i++){	 
			if( Morton[i].center.X() <= temp->max_x &&  Morton[i].center.X() >= temp->min_x){
				determine_bvh_coordinate(temp_max_x,temp_min_x,temp_max_y,temp_min_y,temp_max_z,temp_min_z,Morton[i]);			
			}
		}
		temp->bvh_max_x=temp_max_x;temp->bvh_max_y=temp_max_y;temp->bvh_max_z=temp_max_z;
		temp->bvh_min_x=temp_min_x;temp->bvh_min_y=temp_min_y;temp->bvh_min_z=temp_min_z;
		make_bvh(temp,level,cur_level+1,NULL,temp->min_x,temp->max_x,temp->min_y,temp->max_y,temp->min_z,temp->max_z);
	}

	if(cur_level==1){
		temp->max_x=x_max2;
		temp->min_x=x_min2;
		temp->max_y=y_max2;
		temp->min_y=(y_max2+y_min2)/2;
		temp->max_z=z_max2;
		temp->min_z=z_min2;
		temp_max_x=-9999999,temp_min_x=9999999;temp_max_y=-9999999,temp_min_y=9999999;temp_max_z=-9999999,temp_min_z=9999999;
			for(int i=0;i<triangle_index;i++){
			if( Morton[i].center.X() <= temp->max_x &&  Morton[i].center.X() >= temp->min_x && Morton[i].center.Y() <= temp->max_y &&  Morton[i].center.Y() >= temp->min_y){
				determine_bvh_coordinate(temp_max_x,temp_min_x,temp_max_y,temp_min_y,temp_max_z,temp_min_z,Morton[i]);
			}
		}
		temp->bvh_max_x=temp_max_x;temp->bvh_max_y=temp_max_y;temp->bvh_max_z=temp_max_z;
		temp->bvh_min_x=temp_min_x;temp->bvh_min_y=temp_min_y;temp->bvh_min_z=temp_min_z;
		make_bvh(temp,level,cur_level+1,NULL,temp->min_x,temp->max_x,temp->min_y,temp->max_y,temp->min_z,temp->max_z);
	}

	if(cur_level==2){
		int num=0;
		temp->max_x=x_max2;
		temp->min_x=x_min2;
		temp->max_y=y_max2;
		temp->min_y=y_min2;
		temp->max_z=z_max2;
		temp->min_z=(z_max2+x_min2)/2;

		temp_max_x=-9999999,temp_min_x=9999999;temp_max_y=-9999999,temp_min_y=9999999;temp_max_z=-9999999,temp_min_z=9999999;
		for(int i=0;i<triangle_index;i++){
			 
			if( Morton[i].center.X() <= temp->max_x &&  Morton[i].center.X() >= temp->min_x && Morton[i].center.Y() <= temp->max_y &&  Morton[i].center.Y() >= temp->min_y && Morton[i].center.Z() <= temp->max_z &&  Morton[i].center.Z() >= temp->min_z){
				determine_bvh_coordinate(temp_max_x,temp_min_x,temp_max_y,temp_min_y,temp_max_z,temp_min_z,Morton[i]);
			}
		}
		temp->bvh_max_x=temp_max_x;temp->bvh_max_y=temp_max_y;temp->bvh_max_z=temp_max_z;
		temp->bvh_min_x=temp_min_x;temp->bvh_min_y=temp_min_y;temp->bvh_min_z=temp_min_z;
		for(int i=0;i<triangle_index;i++){
			if( Morton[i].center.X() <= temp->max_x &&  Morton[i].center.X() >= temp->min_x){
				if( Morton[i].center.Y() <= temp->max_y &&  Morton[i].center.Y() >= temp->min_y){
					if( Morton[i].center.Z() <= temp->max_z &&  Morton[i].center.Z() >= temp->min_z){
						num++;
					}
				}
			}
		}
		temp->number=num;
		temp->t= new morton*[num];
		int temp_index=0;
		for(int i=0;i<triangle_index;i++){
			if( Morton[i].center.X() <= temp->max_x &&  Morton[i].center.X() >= temp->min_x){
				if( Morton[i].center.Y() <= temp->max_y &&  Morton[i].center.Y() >= temp->min_y){
					if( Morton[i].center.Z() <= temp->max_z &&  Morton[i].center.Z() >= temp->min_z){
						temp->t[temp_index]=&Morton[i];
						temp_index++;
					}
				}
			}
		}
	}
}
void make_mt_tree(mortonTree *p,int level,int cur_level,char *parent,float x_min2,float x_max2,float y_min2,float y_max2,float z_min2,float z_max2){
	int i,j;
	int k=level;
	float x0,x1,x2;
	float y0,y1,y2;
	float z0,z1,z2;
	x0=x_min2; x2=x_max2; y0=y_min2; y2=y_max2; z0=z_min2; z2=z_max2;
	mortonTree *temp3;
	mortonTree *temp4;
	char str[9];
	float temp_x_min,temp_x_max;
	float temp_y_min,temp_y_max;
	float temp_z_min,temp_z_max;
	static int morton_index=0;
	static int m_t_flag=0;
	static int m_t_flag1=0;
	static int m_t_flag2=0;
	for(i=0;i<8;i++){
		x1=(x0+x2)/2;
		y1=(y0+y2)/2;
		z1=(z0+z2)/2;
		p->child[i] = new mortonTree;
		temp3=p->child[i];
		temp3->code=i;
		temp3->code_[0]=NULL;
		temp3->t=NULL;
	//	itoa(i,str,2);
		if(i==0){
			strcpy(str,"000");
		}
		else{
		if(i==1){
			strcpy(str,"001");
		}
		else if(i==2){
			strcpy(str,"010");
		}
		else if(i==3){
			strcpy(str,"011");
		}
		else if(i==4){
			strcpy(str,"100");
		}
		else if(i==5){
			strcpy(str,"101");
		}
		else if(i==6){
			strcpy(str,"110");
		}
		else if(i==7){
			strcpy(str,"111");
		}
      
		} 
		if(str[0]=='0'){
			temp_x_min=x0;
			temp_x_max=x1;
			//x2=x1;
		}
		else if(str[0]='1'){
			temp_x_min=x1;
			temp_x_max=x2;
			//x0=x1;
		}

		if(str[1]=='0'){
			temp_y_min=y0;
			temp_y_max=y1;
			//y2=y1;
		}
		else if(str[1]='1'){
			temp_y_min=y1;
			temp_y_max=y2;
		}

		if(str[2]=='0'){
			temp_z_min=z0;
			temp_z_max=z1;;
		}
		else if(str[2]='1'){
			temp_z_min=z1;
			temp_z_max=z2;
		}
		if(parent!=NULL)
			strcpy(temp3->code_,parent);
		
		strcat(temp3->code_,str);
		int static num;int flag_;
		num=0; flag_=0;
		for(  ;g_search[cur_level]<triangle_index;g_search[cur_level]++){
			if( strncmp(temp3->code_,Morton[g_search[cur_level]].m,strlen(temp3->code_))==0 ) {
				num++;
				flag_=1;
			}
			else{
				//if(flag_==1)
					break;
			}

		}
		temp3->tri_num=num;
		//////////////////////////////////////////
		temp3->min_x=temp_x_min;
		temp3->max_x=temp_x_max;
		temp3->min_y=temp_y_min;
		temp3->max_y=temp_y_max;
		temp3->min_z=temp_z_min;
		temp3->max_z=temp_z_max;
		if(cur_level!=k){
			make_mt_tree(temp3,k,cur_level+1,temp3->code_,temp_x_min,temp_x_max,temp_y_min,temp_y_max,temp_z_min,temp_z_max);
		}
		if(cur_level==k){
		//	if(cur_level==1)
		//		m_t_flag1=0;
		//	if(cur_level==0)
		//		m_t_flag=0;
		//	if(	temp3->tri_num>0){
		//		temp3->t= new morton*[temp3->tri_num];
		//	}
		//	for( int i=0;i<temp3->tri_num;i++){
		//		temp3->t[i]=&Morton[morton_index];
		//		morton_index++;
		//	}

		}
	}
}
void get_distance_field_morton(int level,int cur_level,int pre_morton){

	int i=0;
	int num_triangle;
	int d_index=0;
	char str[9];
	static int flag=0;
	static int flag2=0;
	for(i=0;i<level*level*level;i++){
		if(i==0&&cur_level==0){
			flag=1;
		//	num_triangle=triangle_in_morton[1024];
		}
		if(i==0 && flag==1 && cur_level==2){
			flag2=1;
		}
		num_triangle=triangle_in_morton[i+1024*flag+64*flag2];
		if(num_triangle>3)
			get_distance_field_morton(level,cur_level++,i+pre_morton*8);
		else{
			int temp=i+pre_morton*8;
			itoa(temp,str,2);
			//voxel_ morton_distance[1500];
		}
	}
}

void testApp::draw()  { // callback function for draw event

	//initGLState();

	if (backgroundBackedUp) { // If background color has been backed up, this should be used
		// for ordinary drawing. 
		//Now set back the clear color in order to draw the real scene
		glClearColor( g_clearColor[0], g_clearColor[1],g_clearColor[2], g_clearColor[3] );   
	}


	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);                   // clear framebuffer color&depth

	bool picking = false;
	//voxel();
	drawStuff( picking);

	checkGlErrors(" after drawStuff() in draw()" );

	//glutSwapBuffers();                                    // show the back buffer (where we rendered stuff)

} // draw()

void testApp::drawForPicking() {
 
  // We need to set the clear color to black, for pick rendering.
  // so let's save the original clear color

  //initGLState();

  if ( !backgroundBackedUp ) { // is the background color backed up? it should be backed up only once, in the 
	                          // beginning. Otherwise, the background color for picking will be backed up and 
	                          // used for normal scene rendering

  glGetDoublev(GL_COLOR_CLEAR_VALUE, g_clearColor); // glGetIntegerv() // glGetDoublev() integer or double values
  backgroundBackedUp = true;
  }


  // clear the background to transparent black color for picking

  
  glClearColor(0, 0, 0, 0); // this black background color is only meant to be used
                               // for the background of the back buffer for rendering in picking.


  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // CLEAR THE COLOR AND DEPTH BUFFER

  bool picking = true;

  drawStuff( picking);


  checkGlErrors(" drawStuff() in drawForPicking()");

  glFinish();
  checkGlErrors("glFinish() in drawForPicking()" );
}



void testApp::drawStuff( bool picking ) {

// normal drawing mode
// Declare an empty uniforms

  Uniforms extraUniforms;
  // build & send proj. matrix to vshader

  
  const Matrix4 projMatrix = makeProjectionMatrix();

  extraUniforms.put("uProjMatrix", projMatrix);


  // use the skyRbt as the eyeRbt

  const Matrix4 eyeRbt = g_eyeRbt;
  const Matrix4 invEyeRbt = inv(eyeRbt);

  const Cvec3 eyeLight1 = Cvec3(invEyeRbt * g_light1Pos ); // g_light1 position in eye coordinates
  const Cvec3 eyeLight2 = Cvec3(invEyeRbt * g_light2Pos ); // g_light2 position in eye coordinates
  
  // send the eye space coordinates of lights to uniforms
  extraUniforms.put("uLight1Pos", eyeLight1);
  extraUniforms.put("uLight2Pos", eyeLight2);

  /*
  safe_glUniform3f(curSS.h_uLight1Pos,  eyeLight1[0], eyeLight1[1], eyeLight1[2] );
  safe_glUniform3f(curSS.h_uLight2Pos,  eyeLight2[0], eyeLight2[1], eyeLight2[2] );
  */

  extraUniforms.put("uLight1Color", g_light1Color );
  extraUniforms.put("uLight2Color", g_light2Color );

  /*
  safe_glUniform4f(curSS.h_uLight1Color,   g_light1Color[0], g_light1Color[1], g_light1Color[2], g_light1Color[3] );
  safe_glUniform4f(curSS.h_uLight2Color,   g_light2Color[0], g_light2Color[1], g_light2Color[2], g_light2Color[3] );
  */

  /*
 	float x=0.0;
	float y=0.0;
	float z=1.0;

	Wm5::Vector3<float> a(x,y,z);
	Wm5::Vector3<float> t1(1,0,0);
	Wm5::Vector3<float> t2(0,1,0);
	Wm5::Vector3<float> t3(-1,-1,0);
	Wm5::Triangle3f tri(t1,t2,t3);

	Wm5::DistPoint3Triangle3f dis(a,tri);
	float distance=dis.Get();
	*/

  // draw the objects in the objectList 
 
  if ( !picking ) { // not picking mode but an ordinary drawing mode
  
   // g_overridingMaterial = g_pickingMat;

    for ( int i  = 0; i < g_objectList.size(); i++ ) { // (5) This loop goes over the list of objects g_objectList and draw each object in the list.
	                                                //     Where and how is this object list created?

     Matrix4 MVM = invEyeRbt * ( *(g_objectList[i]->objectRbt) ) ; // g_currentPickedObject->objectRbt may have been
	                                                              // changed by picking
    //Matrix4 NMVM = normalMatrix(MVM);
  
	 extraUniforms.put("uModelViewMatrix", MVM).put("uNormalMatrix", normalMatrix(MVM) );

	 
	// Cvec4 pickColor = g_objectList[i]->pickColor;
	 //Cvec4 materialColor = g_objectList[i]->objectColor;

	 //std::cout << "Linear [float] Color for the Object to be Drawn For Picking=" << pickColor[0] << ","<< pickColor[1] << "," << 
	//	 pickColor[2]  << "," << pickColor[3] << endl;

	 //g_objectList[i]->material->getUniforms().put("uMaterialColor", pickColor);
	 // for debugging

	// g_overridingMaterial-> getUniforms().put("uMaterialColor", pickColor);

     // UniformextraUniforms.put( "uMaterialColor", pickColor ); // set material color. In the case of
	 // g_overridingMaterial, there are no uniform "uMaterialColor" assigned when
	 // when it is created.

	 // When you put an attribute to extramUniforms, it will not replace the same one in the original uniforms.

	 
     g_objectList[i]->draw( extraUniforms );  // the material Color is also a uniform value, but it is
	                                         // part of Material of this object. It will be taken care of 
	                                         // within the draw method.

     checkGlErrors(" g_objectList[i]->draw( ) in drawStuff()" );
    } // for

	//g_overridingMaterial.reset();

  } // not picking

  else {

     g_overridingMaterial = g_pickingMat;

     for ( int i  = 0; i <g_objectList.size(); i++ ) { // (5) This loop goes over the list of objects g_objectList and draw each object in the list.
	                                                //     Where and how is this object list created?

     Matrix4 MVM = invEyeRbt * ( *(g_objectList[i]->objectRbt) ) ; // g_currentPickedObject->objectRbt may have been
	                                                              // changed by picking
    //Matrix4 NMVM = normalMatrix(MVM);
  
	 extraUniforms.put("uModelViewMatrix", MVM).put("uNormalMatrix", normalMatrix(MVM) );

	 
    Cvec4 pickColor = g_objectList[i]->pickColor;

	//Cvec4 materialColor = g_objectList[i]->objectColor;
	
	//std::cout << "Linear [float] Color for the Object to be Drawn For Picking=" << pickColor[0] << ","<< pickColor[1] << "," << 
	//            pickColor[2]  << "," << pickColor[3] << endl;

    extraUniforms.put( "uMaterialColor", pickColor ); // set material color. In the case of
	                                                 // g_overridingMaterial, there are no uniform "uMaterialColor" assigned when
	                                                  // when it is created.


    checkGlErrors(" pick color in drawStuff( picking) " );



    // the following draw() method will use g_overridingMaterial->draw() if g_overridingMaterial is on

	 g_objectList[i]->draw( extraUniforms );  // the material Color is also a uniform value, but it is
	                                         // part of Material of this object. It will be taken care of 
	                                         // within the draw method.

     checkGlErrors(" g_objectList[i]->draw( ) in drawStuff(picking)" );
    }  // for

	// unset the overriding material
    g_overridingMaterial.reset();
	
  } // picking mode

} // drawStuff() for ordinary rendering or  picking






//If you're not using VAOs, then you would usually call glVertexAttribPointer
//(and the corresponding glEnableVertexAttribArray) right before rendering to setup the state properly. 
//If using VAOs though, you actually call it (and the enable function) inside the VAO creation code
//(which is usually part of some initialization or object creation), since its settings are stored inside the VAO and 
//all you need to do when rendering is bind the VAO and call a draw function.

/*
So in modern OpenGL using VAOs (which is recommended), it's usually similar to this workflow:

//initialization
  glGenVertexArrays
  glBindVertexArray

glGenBuffers
glBindBuffer
glBufferData

glVertexAttribPointer
glEnableVertexAttribArray

  glBindVertexArray(0)

  glDeleteBuffers //you can already delete it after the VAO is unbound, since the
//VAO still references it, keeping it alive (see comments below).

...

//rendering
  glBindVertexArray
glDrawWhatever

--------------------------------------------------------------------------------

*/

/* http://www.lighthouse3d.com/tutorials/glsl-tutorial/the-normal-matrix/ 

			this is needed when the modelview matrix contains a non-uniform scale.
			the correct matrix to transform the normal is the transpose of the inverse of the M matrix. 
			OpenGL computes this for us in the gl_NormalMatrix.
			
*/

//--------------------------------------------------------------

void testApp::initObjects() {


	Options options;
	vector<string> filenames;
	// Process command-line arguments
	for (int i = 1; i < g_argc; ++i) {
		if (!strcmp(g_argv[i], "--ncores")) options.nCores = atoi(g_argv[++i]);
		else if (!strcmp(g_argv[i], "--outfile")) options.imageFile =g_argv[++i];
		else if (!strcmp(g_argv[i], "--quick")) options.quickRender = true;
		else if (!strcmp(g_argv[i], "--quiet")) options.quiet = true;
		else if (!strcmp(g_argv[i], "--verbose")) options.verbose = true;
		else if (!strcmp(g_argv[i], "--help") || !strcmp(g_argv[i], "-h")) {
			printf("usage: pbrt [--ncores n] [--outfile filename] [--quick] [--quiet] "
				"[--verbose] [--help] <filename.pbrt> ...\n");
			return ;
		}
		else filenames.push_back(g_argv[i]);
	}

	// Print welcome banner
	if (!options.quiet) {
		printf("pbrt version %s of %s at %s [Detected %d core(s)]\n",
			PBRT_VERSION, __DATE__, __TIME__, NumSystemCores());
		printf("Copyright (c)1998-2012 Matt Pharr and Greg Humphreys.\n");
		printf("The source code to pbrt (but *not* the book contents) is covered by the BSD License.\n");
		printf("See the file LICENSE.txt for the conditions of the license.\n");
		fflush(stdout);
	}
	pbrtInit(options);
	// Process scene description
	PBRT_STARTED_PARSING();
	if (filenames.size() == 0) {
		// Parse scene from standard input
		ParseFile("-");
	} else {
		// Parse scene from input files
		for (int i = 0; i < filenames.size(); i++)
			if (!ParseFile(filenames[i]))
				Error("Couldn't open scene file \"%s\"", filenames[i].c_str());
	}
	//pbrtCleanup();




}



void testApp::initObjects2() {
int ibLen, vbLen;


// 1: create a ground
	static const float groundY = -5.0;      // y coordinate of the ground
    static const float groundSize = 8.0;   // half the ground length

  // temporary storage for a plane geometry
  getPlaneVbIbLen( vbLen, ibLen); // get the sizes of the vertex buffer and the 
                                 // index buffer for a plane. The vertex buffer
                                 // size is the number of vertices.
  vector<VertexPNTBX> vtxGround (vbLen);
  vector<unsigned short> idxGround (ibLen);

  makePlane( groundSize * 2, vtxGround.begin(), idxGround.begin() );

  // vtxGround is an array of generic vertices (position, normal, tex coord, tangent, binormal)
  /*
  // A x-z plane at y = g_groundY of dimension [-g_groundSize, g_groundSize]^2
  VertexPN vtxGround[4] = {
    VertexPN( -groundSize, groundY, groundSize, 0, 1, 0),
    VertexPN( groundSize, groundY,  groundSize, 0, 1, 0),
    VertexPN(  groundSize, groundY, -groundSize, 0, 1, 0),
    VertexPN(  -groundSize, groundY, -groundSize, 0, 1, 0),
  };
  unsigned short idxGround[] = {0, 1, 2, 0, 2, 3};
  */
  //shared_ptr<Geometry> groundGeometry  ( new Geometry( &vtxGround[0], &idxGround[0], 4, 6,  &sqTex[0], numOfTexCoords  )  );
  shared_ptr<Geometry> groundGeometry  ( new SimpleIndexedGeometryPNTBX( &vtxGround[0], &idxGround[0], vbLen, ibLen  )  );

 /*
  SimpleIndexedGeometryPNTBX => init: vbo(new FormattedVbo( Vertex::FORMAT ) ), ibo(new FormattedIbo(size2IboFmt(sizeof(Index)))) 
   where Vertex is either VertexPN, ...:

  const VertexFormat VertexPN::FORMAT = VertexFormat(sizeof(VertexPN))
	  .put("aPosition", 3, GL_FLOAT, GL_FALSE, offsetof(VertexPN, p))
	  .put("aNormal", 3, GL_FLOAT, GL_FALSE, offsetof(VertexPN, n));
  */
  // 2: create a cube
 // int ibLen, vbLen;

  getCubeVbIbLen(vbLen, ibLen);

  // Temporary storage for cube geometry
  // T = tangent, X = coordinates

  vector<VertexPNTBX> vtxCube(vbLen); // vtx local

  vector<unsigned short> idxCube(ibLen); // idx local

  // makecube<VertexPNTBX, unsigned short>( vtxCube.begin(), idxCube.begin() );

  // vtxCube and idxCube are vertices whose stroages are already
  // allocated, so that you can access each element of a vertex by means
  // of iterator.

  makeCube(1, vtxCube.begin(), idxCube.begin() ); // fill vtx and idx 

 shared_ptr<Geometry> cubeGeometry (  new SimpleIndexedGeometryPNTBX( &vtxCube[0], &idxCube[0], vbLen, ibLen ) ); // reset(T * p)

  //shared_ptr<Geometry> cubeGeometry (  new Geometry( &vtxCube[0], &idxCube[0], vbLen, ibLen, &sqTex[0], numOfTexCoords  ) ); // reset(T * p)

  // 3: create a sphere
  
  int slices = 100;
  int stacks = 100;

  getSphereVbIbLen(slices, stacks, vbLen, ibLen);

  // Temporary storage for cube geometry

  vector<VertexPNTBX>  vtxSphere (vbLen);

  vector<unsigned short> idxSphere (ibLen);

  float radius = 3;

  makeSphere(radius, slices, stacks,  vtxSphere.begin(), idxSphere.begin() );

  //geometry.h: typedef SimpleIndexedGeometry<VertexPNTBX, unsigned short> SimpleIndexedGeometryPNTBX;

  shared_ptr<Geometry> sphereGeometry ( new SimpleIndexedGeometryPNTBX( &vtxSphere[0], &idxSphere[0], vbLen, ibLen ) ); // reset(T * p)
 
  // or  shared_ptr<Geometry> sphereGeometry =  new Geometry( &vtx[0], &idx[0], vbLen, ibLen ); // reset(T * p)
  // NOTE: here vtx and idx arrays are copied to the vertex buffer object internally, so this data need not be global.

  // create the object frames for the created geometry

  // The following does not work, because the  matrix created by SgRbtNode::makeTranslation() is
  //	destroyed outside of this function initObjects(). To avoid it, create the matrix by the "new" method.
 //	The objects created by new methods remain unless removed explicitly. This is handled by shared_ptr<>. 
																				   
//  shared_ptr<SgRbtNode> groundRbt ( &SgRbtNode::makeTranslation( Cvec3(0,0,0) ) ); 
 // shared_ptr<SgRbtNode>  cubeRbt ( &SgRbtNode::makeTranslation( Cvec3(5.0,0,0)  ) );
  // shared_ptr< SgRbtNode>  sphereRbt ( &SgRbtNode::makeTranslation( Cvec3(0,0,0) ) );
  
  
  shared_ptr<SgRbtNode> groundRbt ( new SgRbtNode( SgRbtNode::makeTranslation( Cvec3(0,0,0) ) ) ); // this uses the non-default copy constructor ?
  shared_ptr<SgRbtNode> cubeRbt ( new SgRbtNode( SgRbtNode::makeTranslation( Cvec3(5.0,0,0)  ) )  );
  shared_ptr< SgRbtNode> sphereRbt ( new SgRbtNode ( SgRbtNode::makeTranslation( Cvec3(0,0,0) ) ) );

 

 // shared_ptr<Object> ground ( new Object( groundRbt, groundGeometry, g_bumpFloorMat) );
  shared_ptr<Object> ground ( new Object( groundRbt, groundGeometry, g_bumpFloorMat) );
  shared_ptr<Object> cube ( new Object( cubeRbt, cubeGeometry, g_blueDiffuseMat) );
  shared_ptr<Object> sphere ( new Object( sphereRbt, sphereGeometry, g_redDiffuseMat) );


  // 1: create the object id color for picking purpose

  Cvec4 pickColor;
  unsigned int id; // 32 bit unsigned



  id = 100;
  id = id << 8;
  id = id | 255 ; // id for  ground


  id=3;
  pickColor = g_picker.idToColor(id);
  
  ground->pickColor = pickColor; // this stored pickColor will be sent to the shader Uniform variable when drawing 

  // store the objects in the object list

  g_objectList.push_back( ground );

  // add the object and the id to the list for picking
  g_picker.addToMap( id, ground );



  // 2: the same for the cube
  id= 200;
  id = id << 8;
  id = id | 255; // id for  cube 

  id=1;

  pickColor  = g_picker.idToColor(id );

  cube->pickColor = pickColor;

  g_objectList.push_back( cube );


  g_picker.addToMap( id, cube );


 
  // 3: the same for sphere
  id = 255;
  id = id << 8;
  id = id | 255; // id for  sphere 


  id=2;
  pickColor = g_picker.idToColor(id);

  sphere->pickColor  = pickColor;

  g_objectList.push_back( sphere );

  g_picker.addToMap( id, sphere );

  

 

};

 



void testApp::initGLState() {
	//glBindFramebuffer(GL_READ_FRAMEBUFFER, 0); 

	glClearColor(128./255., 200./255., 255./255., 1.0); // sky color

	//glClearColor(128./255., 0./255., 0./255., 1.0); // sky color

	glClearDepth(0.);
	//glClearDepth(1.0); // the default value is 0.0


	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	glPixelStorei(GL_PACK_ALIGNMENT, 1);
	glCullFace(GL_BACK);
	glEnable(GL_CULL_FACE);

	glEnable(GL_DEPTH_TEST);
	//glDisable(GL_DEPTH_TEST);

	glDepthFunc(GL_GREATER);
	//glDepthFunc(GL_LEQUAL);


	glColorMask( GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);

	glDisable(GL_BLEND);
	glDisable(GL_ALPHA_TEST);


	// bind the default framebuffer: 
	glBindFramebuffer(GL_FRAMEBUFFER, 0); // frame buffer 0 will be used both for reading and writing pixels.

	glReadBuffer(GL_BACK); // default, the same with glDrawBuffer()
	glDrawBuffer(GL_BACK); // GL_BACK is the draw buffer for the zero framebuffer

	//glReadBuffer(GL_FRONT); // default, the same with glDrawBuffer()
	if (!g_Gl2Compatible)
		glEnable(GL_FRAMEBUFFER_SRGB); // For opengl3.x, enable the sRGB framebuffer update and blending capability

	checkGlErrors("Gl Error in initGLStates");

}


// // set a texture reference
//	void setUniformTexture(const string & name, ofBaseHasTexture& img, int textureLocation);
//	void setUniformTexture(const string & name, ofTexture& img, int textureLocation);
//	void setUniformTexture(const string & name, int textureTarget, GLint textureID, int textureLocation);
	
void testApp::initMaterials() {

	// Create some prototype materials
	// file paths are relative to the folder where .exe file goes, not where the project file exists.

	ShaderMaterial diffuse("shaders/basic-gl3.vshader", "shaders/diffuse-gl3.fshader"); 
	// get active uniforms and attributes and bind indices to them.

	ShaderMaterial solid("shaders/basic-gl3.vshader", "shaders/solid-gl3.fshader");

	//////////////////////////////////////////////////////////////////////
	g_diffuseWithTexture=new ShaderMaterial("shaders/basic-gl3.vshader", "shaders/diffuse-texture-gl3.fshader"); 
	g_diffuseWithoutTexture=new ShaderMaterial("shaders/basic-gl3.vshader", "shaders/diffuse-gl3.fshader"); 
	///////////////////////////////////////////////////////////////

	// copy diffuse prototype and set red color
	g_redDiffuseMat.reset(new ShaderMaterial(diffuse));  // ShaderMaterial(diffuse): uses the default copy constructor

	g_redDiffuseMat->getUniforms().put("uMaterialColor", Cvec4f(1, 0, 0,1.0));
	//g_redDiffuseMat->getUniforms().put("uTexUnit0", shared_ptr<ImageTexture>( new ImageTexture("reachup.ppm", true) ) );

	// copy diffuse prototype and set blue color
	g_blueDiffuseMat.reset(new ShaderMaterial(diffuse));
	g_blueDiffuseMat->getUniforms().put("uMaterialColor", Cvec4f(0, 0, 1,1.0));

	// normal mapping material
	g_bumpFloorMat.reset(new ShaderMaterial("shaders/normal-gl3.vshader", "shaders/normal-gl3.fshader"));
	g_bumpFloorMat->getUniforms().put("uTexColor", shared_ptr<ShaderImageTexture>(new ShaderImageTexture("image/Fieldstone.ppm", true)));
	g_bumpFloorMat->getUniforms().put("uTexNormal", shared_ptr<ShaderImageTexture>(new ShaderImageTexture("image/FieldstoneNormal.ppm", false)));

	// copy solid prototype, and set to wireframed rendering
	g_arcballMat.reset(new ShaderMaterial(solid));
	g_arcballMat->getUniforms().put("uMaterialColor", Cvec4f(0.27f, 0.82f, 0.35f, 1.0));
	g_arcballMat->getRenderStates().polygonMode(GL_FRONT_AND_BACK, GL_LINE);

	// copy solid prototype, and set to color white
	g_lightMat.reset(new ShaderMaterial(solid));
	g_lightMat->getUniforms().put("uMaterialColor", Cvec4f(1, 1, 1,1));

	// pick shader
	g_pickingMat.reset(new ShaderMaterial("shaders/basic-gl3.vshader", "shaders/pick-gl3.fshader") );



};


//--------------------------------------------------------------
void testApp::windowResized(int w, int h){  // call back function for event processing
 
	// instance->windowW = w; => the new window size is already set before calling windowResized()

	// instance->windowH = h;
  g_windowHeight = h;
  g_windowWidth = w;
 
  
  glViewport(0, 0, g_windowWidth, g_windowHeight);



  cout   << "Size of window is now " << g_windowWidth << "x" << g_windowHeight << endl;
  cout << "results of ofGetHeight and ofGetWidth= " << ofGetWidth() << "x" << ofGetHeight() << endl;

  //cerr  << "Size of window is now " << g_windowWidth << "x" << g_windowHeight << endl;
  //system ("PAUSE");

  updateFrustFovY();
 
  // At every frame, display() callback is called to redraw the
	// scene. So, windowResized event handler needs not do anything to redraw the scene.
	
}


//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button){ // call back function for event processing

 // This callback is called every time the pressed mouse is moved a little.
// x, y: the current mouse position after this little  motion is finished.


  cout  << "dragged mouse button " << button << "X = " << x << "Y = " << y << endl;
  // Here the moved button is 0, meaning that which button is pressed while moving the mouse is ignored.
 
  cout <<  "Control Key Pressed =" << ofGetKeyPressed( OF_KEY_CONTROL ) << endl;
  cout <<  "Shift  Key Pressed =" << ofGetKeyPressed( OF_KEY_SHIFT ) << endl;
  cout <<  "ALT Key Pressed =" << ofGetKeyPressed( OF_KEY_ALT ) << endl;
  

  const double dx = x - g_prev_mouseClickX;
  const double dy = g_windowHeight - y - 1 - g_prev_mouseClickY;
  
  Matrix4 m;
  
  g_prev_mouseClickX = x;
  g_prev_mouseClickY = g_windowHeight - y - 1;

  if ( ofGetKeyPressed( OF_KEY_CONTROL ) && !ofGetKeyPressed( OF_KEY_ALT ) )  {
	  // translate the selected object
      switch ( button ) {
		  case OF_MOUSE_BUTTON_LEFT:
			  cout  << " left button moves" << endl;
			  m = Matrix4::makeTranslation( Cvec3( dx, dy, 0.0) * 0.01 ); 
			  //m = Matrix4::makeTranslation( Cvec3( dx, 0.0, 0.0) * 0.01 ); 
			  break;
		  case OF_MOUSE_BUTTON_RIGHT:
			  cout  << " right button moves" << endl;
			  m = Matrix4::makeTranslation( Cvec3( 0.0, 0.0, -dy) * 0.01 ); 
			  break;

		  default: 
			  m = Matrix4::makeTranslation( Cvec3( 0.0, 0.0, 0.0)  ); 
	  } // switch

	   g_eyeRbt *= m;
  } // if (! g_rotation)

  else if ( ofGetKeyPressed( OF_KEY_CONTROL) && ofGetKeyPressed( OF_KEY_ALT) ) { //  rotate the selected object

	  switch ( button ) {
		  case OF_MOUSE_BUTTON_LEFT:

			  //inline static ofMatrix4x4 newRotationMatrix( float angle, const ofVec3f& axis);
			  m = Matrix4::makeXRotation(-dy ) * Matrix4::makeYRotation( dx );
			  // m = Matrix4::makeXRotation( dx); 
			  break;
		  case OF_MOUSE_BUTTON_RIGHT:
			  m = Matrix4::makeZRotation( dy ); 
			  break;

		  default: 
			  m = Matrix4::makeTranslation( Cvec3( 0.0, 0.0, 0.0)  ); 
	  } // switch

	  g_eyeRbt *= m;
  } // else if
  
  

  else if ( g_picked_mode )  { // An object has been picked by pressing the left or right mouse

   if (   ofGetKeyPressed( OF_KEY_SHIFT ) && !ofGetKeyPressed( OF_KEY_ALT) )   { // translate the selected object
	 switch ( button ) {
	  case OF_MOUSE_BUTTON_LEFT:
		   cout  << " left button moves" << endl;
		   m = Matrix4::makeTranslation( Cvec3( dx, dy, 0.0) * 0.01 ); 
		   //m = Matrix4::makeTranslation( Cvec3( dx, 0.0, 0.0) * 0.01 ); 
		   break;
	  case OF_MOUSE_BUTTON_RIGHT:
		  cout  << " right button moves" << endl;
		   m = Matrix4::makeTranslation( Cvec3( 0.0, 0.0, -dy) * 0.01 ); 
		   break;

	  default: 
		   m = Matrix4::makeTranslation( Cvec3( 0.0, 0.0, 0.0)  ); 
	  } // switch

	  assert( ("g_currentPickedRbtNode should not be Null", g_currentPickedObject != nullptr) );

	  *(g_currentPickedObject->objectRbt) = m * *(g_currentPickedObject-> objectRbt) ;

	  //////////////////// primitive�� �����Ͽ�, o2w �ٲ� �� �ֵ��� ����.////////





    } // if ( translate )

    else if ( ofGetKeyPressed( OF_KEY_SHIFT) && ofGetKeyPressed( OF_KEY_ALT) ) { //  rotate the selected object
	   
		  switch ( button ) {
	       case OF_MOUSE_BUTTON_LEFT:

			//inline static ofMatrix4x4 newRotationMatrix( float angle, const ofVec3f& axis);
		     m = Matrix4::makeXRotation(-dy ) * Matrix4::makeYRotation( dx );
		  // m = Matrix4::makeXRotation( dx); 
		     break;
	       case OF_MOUSE_BUTTON_RIGHT:
		     m = Matrix4::makeZRotation( dy ); 
		     break;

	       default: 
		     m = Matrix4::makeTranslation( Cvec3( 0.0, 0.0, 0.0)  ); 
	      } // switch

		  assert( ("g_currentPickedRbtNode should not be Null", g_currentPickedObject != nullptr) );

		  *(g_currentPickedObject->objectRbt) = m  *  *(g_currentPickedObject-> objectRbt) ;

       } // else if

  } // (g_picked_mode)
  
 
} // mouseDragged()





//--------------------------------------------------------------
void testApp::mouseReleased(int x, int y, int button){


} // mouseReleased()




//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y ){

	// This callback is called every time the pressed mouse is moved a little.
	// x, y: the current mouse position after this little  motion is finished.


	
}


//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button){
	
  cout << "mouse x,y = " << x << "," << y << endl;

  g_prev_mouseClickX = x;
  g_prev_mouseClickY = g_windowHeight - y - 1;  // conversion from GLUT window-coordinate-system to OpenGL window-coordinate-system
  //g_prev_mouseClickY = y;

  /*
  cout  << "pressed mouse =" <<  button << endl;
  cout  << "shift  modifier key pressed? = " << ofGetKeyPressed(OF_KEY_SHIFT) << endl;
  */

  g_pressed_button = button; // the pressed button has meaning for moving the picked object or the camera later

  
  if ( ofGetKeyPressed( OF_KEY_SHIFT ) ) { // shift +  any mouse press leads to pickin an object
    cout  << "draw for picking " << endl;
	// for temp debugginhg
	
	drawForPicking();      //    In the picking mode, you render the simplified version of the scene to the back buffer,
		                       //     while maintaining the scene of the screen intact, because it is in the front buffer.
		                      
	   //  Read pixel operation needed for picking is performed with respect to the back buffer, not to the front buffer

	// for temp debugging

	g_currentPickedObject = g_picker.getRbtNodeAtXY( g_prev_mouseClickX, g_prev_mouseClickY );

	
	 // g_currentPickedRbtNode points to one of g_objectRbt[], which has been picked.

     // g_currentPickedRbtNode will be NULL, if no object has been actually picked.

   if ( g_currentPickedObject == nullptr ) {

		  cout << "no object has been picked" << endl;
		  g_picked_mode = false;

	 }
   else {
          cout << "an object has been picked" << endl;

		  g_picked_mode = true;
     }

  } // g_picking_mode

  // after drawForPicking(), normal draw is called, which is in fact called every frame.

} // mousePressEvent()




//--------------------------------------------------------------
void testApp::keyPressed  (int key){ 
//	OF_KEY_LEFT_CONTROL,  OF_KEY_LEFT_SHIFT,
// OF_KEY_LEFT_ALT,
//	OF_MOUSE_BUTTON_LEFT
 /* 
  cout << "pressed key=" << key<< endl;
  cout << "OF_KEY_SHIFT= " << OF_KEY_SHIFT << endl;
  cout << "OF_KEY_CONTROL= " << OF_KEY_CONTROL << endl;
  cout << "OF_KEY_ALT= " << OF_KEY_ALT << endl;
*/

  switch (key) {

  case OF_KEY_ESC: 
    exitApp();                                  // ESC 
  case OF_KEY_CONTROL: 
    g_camera_mode = true;
	break;

  case 'h': 
    cout << " ============== H E L P ==============\n\n"
    << "h\t\thelp menu\n"
    << "s\t\tsave screenshot\n"
    << "f\t\tToggle flat shading on/off.\n"
    << "ESC\t\t exit\n"
    << "Cntrl\t\t  camera moving mode\n"
	<< "Alt\t\t rotate the selected object or the camera\n"
    << "Shift\t\t  picking mode\n" << endl;
    break;

  case 's': 
    glFlush();
    writePpmScreenshot(g_windowWidth, g_windowHeight, "out.ppm");
	break;

  case 'r':
	  render_flag=1;
	  pbrtWorldEnd();

	  break;

  default: break;

 } // switch
	
} // keyPressed()

//--------------------------------------------------------------
void testApp::keyReleased(int key){ 


  //cout   << "released key=" << key << endl;
  switch (key) {

   case OF_KEY_CONTROL: 
	  g_camera_mode = false;
	  break;
  
   case OF_KEY_SHIFT: 
	   g_picked_mode  = false;
	   break;

   default: 
	   break;
  }

}



//--------------------------------------------------------------
void testApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void testApp::dragEvent(ofDragInfo dragInfo){ 

}

