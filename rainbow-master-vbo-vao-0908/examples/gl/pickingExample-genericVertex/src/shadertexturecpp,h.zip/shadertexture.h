#ifndef TEXTURE_H
#define TEXTURE_H

#include "glsupport.h"
#include "ppm.h"

class ShaderTexture {
public:
  // Must return one of GL_SAMPLER_1D, GL_SAMPLER_2D, GL_SAMPLER_3D, GL_SAMPLER_CUBE,
  // GL_SAMPLER_1D_SHADOW, or GL_SAMPLER_2D_SHADOW, as its intended usage by GLSL shader
  virtual GLenum getSamplerType() const = 0;

  // Binds the texture. (The caller is responsible for setting the active texture unit)
  virtual void bind() const = 0;

  virtual ~ShaderTexture() {}
};

//----------------------------------------
// One concrete implementation of Texture
//----------------------------------------

class ShaderImageTexture1Df : public ShaderTexture {
 
	GlTexture tex;

public:
  // Loades a PPM image files with three channels, and create
  // a 2D texture off it. if `srgb' is true, the image is assumed
  // to be in SRGB color space
  ShaderImageTexture1Df(const char* ppmFileName, bool srgb, bool integerIndex); // implemented in texture.cpp

  virtual GLenum getSamplerType() const {
    return GL_SAMPLER_1D;
  }

  virtual void bind() const {
    glBindTexture(GL_TEXTURE_1D, tex);
  }
};


class ShaderImageTexture2D : public ShaderTexture {
 
	GlTexture tex;

public:
  // Loades a PPM image files with three channels, and create
  // a 2D texture off it. if `srgb' is true, the image is assumed
  // to be in SRGB color space
  ShaderImageTexture2D(const char* ppmFileName, bool srgb); // implemented in texture.cpp
  ShaderImageTexture2D(  const  GLubyte *pixData, const int width, const int height, bool srgb ); // implemented in texture.cpp
 
  virtual GLenum getSamplerType() const {
    return GL_SAMPLER_2D;
  }

  virtual void bind() const {
    glBindTexture(GL_TEXTURE_2D, tex);
  }
};


class ShaderImageTexture2Df : public ShaderTexture {
 
	GlTexture tex;

public:
  // Loades a PPM image files with three channels, and create
  // a 2D texture off it. if `srgb' is true, the image is assumed
  // to be in SRGB color space
  ShaderImageTexture2Df(const char* ppmFileName, bool srgb, bool integerIndex); // implemented in  shadertexture.cpp
   ShaderImageTexture2Df(  const  float *pixData, const int width, const int height ); // implemented in dhadertexture.cpp
  virtual GLenum getSamplerType() const { 
    return GL_SAMPLER_2D;
  }

  virtual void bind() const {
    glBindTexture(GL_TEXTURE_2D, tex);
  }
};

class ShaderImageTexture3D : public ShaderTexture {
 
	GlTexture tex;

public:
  // Loades a PPM image files with three channels, and create
  // a 2D texture off it. if `srgb' is true, the image is assumed
  // to be in SRGB color space
  ShaderImageTexture3D(const char* ppmFileName, bool srgb, bool integerIndex); // implemented in texture.cpp

  virtual GLenum getSamplerType() const {
    return GL_SAMPLER_3D;
  }

  virtual void bind() const {
    glBindTexture(GL_TEXTURE_3D, tex);
  }
};


#endif