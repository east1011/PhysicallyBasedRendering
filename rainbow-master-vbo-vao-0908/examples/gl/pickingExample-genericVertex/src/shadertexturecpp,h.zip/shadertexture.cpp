
#include <vector>

#include "ppm.h"
//#include "glsupport.h"
#include "shadertexture.h"

//#include "phaseFunction.h"

//extern float g_phaseFunction[];

using namespace std;

//extern QOpenGLFunctions_3_0 *m_funcs;
extern bool g_Gl2Compatible;

ShaderImageTexture1Df::ShaderImageTexture1Df(const char* ppmFileName, bool srgb, bool integerIndex) {
  int width;

  vector<float> floatData;

  read1DFloatTex(ppmFileName, width, floatData, integerIndex);

  glBindTexture(GL_TEXTURE_1D, tex); // tex ( member of the class) : tex Handle, set the current texture

 // if (g_Gl2Compatible)
 //   glTexParameteri(GL_TEXTURE_1D, GL_GENERATE_MIPMAP, GL_TRUE);
  glTexImage1D(GL_TEXTURE_1D, 0, GL_R32F, width, 
               0, GL_RED, GL_FLOAT, &floatData[0]);
  
  //if (!g_Gl2Compatible)
  //  glGenerateMipmap(GL_TEXTURE_1D);
  // glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
  glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  //glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

  checkGlErrors("ImageTexture::ImageTexture");
}

ShaderImageTexture2D::ShaderImageTexture2D( const  GLubyte *pixData, const int width, const int height, bool srgb ) {

glBindTexture(GL_TEXTURE_2D, tex); // tex ( member of the class) : tex Handle, set the current texture

  //if (g_Gl2Compatible)
  //  glTexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP, GL_TRUE);

  glTexImage2D(GL_TEXTURE_2D, 0, (!srgb) || g_Gl2Compatible ? GL_RGB : GL_SRGB, width, height,
               0, GL_RGB, GL_UNSIGNED_BYTE, &pixData[0]);

  //if (!g_Gl2Compatible)
  //  glGenerateMipmap(GL_TEXTURE_2D);

  //glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

  checkGlErrors("ImageTexture::ImageTexture");	
	
} 
ShaderImageTexture2D::ShaderImageTexture2D(const char* ppmFileName, bool srgb) {
  int width, height;

  vector<PackedPixel> pixData;

  ppmRead(ppmFileName, width, height, pixData);

  glBindTexture(GL_TEXTURE_2D, tex); // tex ( member of the class) : tex Handle, set the current texture

  //if (g_Gl2Compatible)
  //  glTexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP, GL_TRUE);

  glTexImage2D(GL_TEXTURE_2D, 0, (!srgb) || g_Gl2Compatible ? GL_RGB : GL_SRGB, width, height,
               0, GL_RGB, GL_UNSIGNED_BYTE, &pixData[0]);

  //if (!g_Gl2Compatible)
  //  glGenerateMipmap(GL_TEXTURE_2D);

  //glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

  checkGlErrors("ImageTexture::ImageTexture");
}

ShaderImageTexture2Df::ShaderImageTexture2Df( const  float *pixData, const int width, const int height ) {

glBindTexture(GL_TEXTURE_2D, tex); // tex ( member of the class) : tex Handle, set the current texture

  //if (g_Gl2Compatible)
  //  glTexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP, GL_TRUE);

  glTexImage2D(GL_TEXTURE_2D, 0, GL_R32F, width, height,
               0, GL_RED, GL_FLOAT, &pixData[0]);

  //if (!g_Gl2Compatible)
  //  glGenerateMipmap(GL_TEXTURE_2D);

  //glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

  checkGlErrors("ImageTexture::ImageTexture");	
	
} 

ShaderImageTexture2Df::ShaderImageTexture2Df(const char* ppmFileName, bool srgb, bool integerIndex) {
  int width, height;

  vector<float> floatData;

  read2DFloatTex(ppmFileName, height, width, floatData, integerIndex);

  /*
  By issuing the glBindTexture() for the first time with texName, we are creating a texture object
  which is 2D and contains some initial default values or properties. 

  You will notice that we will call glBindTexture() again later with texName. 
  When glBindTexture() is called with a previously created texture object, 
  that texture object becomes active.
  Therefore, the next call to glBindTexture() will make texName the active or current texture state. 
  */

  glBindTexture(GL_TEXTURE_2D, tex); // tex ( member of the class) : tex Handle, set the current texture
  
  // We've got a texture name and we've created a texture with the glBindTexture() command, 
  // now we can specify some properties or parameters for the texture. 
  // If we don't specify any parameters, the default values will be used. 


  //if (g_Gl2Compatible)
  //  glTexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP, GL_TRUE);

  glTexImage2D(GL_TEXTURE_2D, 0, GL_R32F, width, height,
               0, GL_RED, GL_FLOAT, &floatData[0]);
  
  
  //glTexImage1D is how we allocate storage for the texture and pass data to the texture. It is similar to glBufferData
  //The last three params:  how to read the texture data in our array = a description of how the texture data is stored in the user's array.


  // The third parameter is the format that OpenGL will use to store the texture's data.
  // => . The format of an image stored in a texture is controlled by OpenGL itself. 
  // The user tells it what format to use, but the specific arrangements of bytes is up to OpenGL. 
  // This allows different hardware to store textures in whatever way is most optimal for accessing them.



  //if (!g_Gl2Compatible)
  //  glGenerateMipmap(GL_TEXTURE_2D);

  //glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
  // glSamplerParameteri etc. introduced since Opengl 3.3; we are using opengl 3.1

  //glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  //glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

  checkGlErrors("ImageTexture::ImageTexture");
}

ShaderImageTexture3D::ShaderImageTexture3D(const char* texFileName, bool srgb, bool integerIndex) {
   int depth, height, width;
  vector<float> distData;

 
  read3DFloatTex(texFileName, depth, height, width,  distData, integerIndex);
  
  // let g_phaseFunction points to distData so that it could be transferred to shader as a uniform variable
  // texLength == nRadii; texLengthY == nSpectralSamples; texLengthZ = nThetas
 // for ( int i = 0; i < nRadii * nSpectralSamples * nThetas; i++ ) {
 //      g_phaseFunction[i] = distData[i];
 // }


  
  glBindTexture(GL_TEXTURE_3D, tex); // tex ( member of the class ShaderImageTexture3D) : tex Handle, set the current texture

  //if (g_Gl2Compatible)
  //  glTexParameteri(GL_TEXTURE_3D, GL_GENERATE_MIPMAP, GL_TRUE);

  // We've got a texture name and we've created a texture with the glBindTexture() command, 
  // now we can specify some properties or parameters for the texture

  glTexImage3D(GL_TEXTURE_3D, 0, GL_R32F, width, height, depth,
               0, GL_RED, GL_FLOAT, &distData[0]);

  //if (!g_Gl2Compatible)
  //  glGenerateMipmap(GL_TEXTURE_3D);

  //glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
  // GL_LINEAR Returns the weighted average of  the  four  texture
   //                        elements  that  are  closest  to  the center of the
   //                        pixel being textured.   These  can  include  border
   //                        texture   elements,
  glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);

  checkGlErrors("ImageTexture::ImageTexture");
}

